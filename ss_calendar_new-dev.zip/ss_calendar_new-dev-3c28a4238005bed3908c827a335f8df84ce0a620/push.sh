git pull
git add .
git commit -m "debug"
git push