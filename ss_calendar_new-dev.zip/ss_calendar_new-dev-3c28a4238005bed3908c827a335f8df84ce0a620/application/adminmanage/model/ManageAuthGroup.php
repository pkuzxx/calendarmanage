<?php
namespace app\adminmanage\model;
use think\Model;
class ManageAuthGroup extends Model
{









}
